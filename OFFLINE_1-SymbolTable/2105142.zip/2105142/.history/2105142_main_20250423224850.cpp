#include <bits/stdc++.h>
using namespace std;

#include "2105142_SymbolTable.cpp"
 

int main()
{
    int num_buckets;
    cout <<"num_buckets_ ";
    string line;
    while(1){
        getline(cin,line);
        stringstream ss(line);
        string word;
        cout<<ss<<endl;

    }
}