#include <bits/stdc++.h>
using namespace std;

#include "2105142_SymbolTable.cpp"
 
int main()
{
    int num_buckets;
    cout <<"num_buckets_ ";
    char test;
    while(1){
        cin>>
    }
}