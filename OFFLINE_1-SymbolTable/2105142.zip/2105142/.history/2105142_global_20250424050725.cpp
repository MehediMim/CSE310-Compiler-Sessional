#ifndef GLOBAL_H
#define GLOBAL_H

extern int tableCounter;  

#endif
