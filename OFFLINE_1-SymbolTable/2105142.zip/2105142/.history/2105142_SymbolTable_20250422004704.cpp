#include <bits/stdc++.h>
using namespace std;

#include "2105142_symbolInfo.cpp"
#include "2105142_scopeTable.cpp"
class SymbolTable
{
private:
    ScopeTable** scopetableList;
    ScopeTable* current_scopetable;

public:
    
};